---
name: bug 提交模板
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**bug描述**
A clear and concise description of what the bug is.

**操作步骤**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**分支名及平台:**
 - 平台: [ubuntu windows]
 - 分支名 [e.g. chrome, safari]
